#include <iostream>
#include <cstring>
#include <cstdlib>
#include <conio.h>
#include <stdio.h>
#include <fstream >

using namespace std; 

class KaySif {
	private : 
	char metin[1024]; 
	char sifreliMetin[1024];
	char desifreliMetin[1024]; 
	string alfabe= "abcdefghijklmnopqrstuvwxyz" ; // 26 harf  // abcz  = defc
	int anahtar = 3 ; // anahtar 3 ise sezar �if. 
	int uzunluk; 
	public: 
	int menu(); 
	void inputAl(); 
	void sifrele(); 
	void desifrele(); 
	void kaydet(); 
	void oku(); 	
};

int KaySif::menu() 
{
	int secim; 	
	do {
	
		cout<<"\nKaydirmali Sifreleme Algoritmasi ile Dosyaya Kaydetme islemi "<< endl; 
		cout<<"1- sifrele "<<endl; 
		cout<<"2- deSifrele "<<endl; 
		cout<<"3- Dosyaya Sifreli Kaydet  "<<endl; 
		cout<<"4- Dosyadaki Sifreli Metni Oku  "<<endl; 
		cout<<"0- CIKIS  "<<endl; 
		cout<<"seciminiz :  "<<endl; 
	
		secim= getche()- '0'; 
		system("cls"); 
		
		cout<<endl<< endl; 
			
	} while( secim <0 || secim >4  ); 
	
	return secim; 
}
void KaySif :: inputAl() 
{
	char key[5]; 
	cout<<"anahtar : "; 
	fgets(key, 5, stdin); 
	anahtar = atoi (key); 
	anahtar = anahtar%26;
	if(anahtar<0)
	anahtar =0;  
	cout<<"Metin : "; 
	fgets(metin, 1024, stdin);
	strlwr(metin);  
	uzunluk = strlen(metin); 
	metin[uzunluk-1]= '\0'; 
	cout<<"metin : "<< metin<< endl; 
}

void KaySif::sifrele() 
{
	inputAl(); 
	
	int i=0; 
	while ( i < uzunluk ) 
	{
		bool durum =false; 
		for( int j=0; j<26; j++   ) 
		{
			int index=j; 
			if( metin[i]== alfabe[j] ) 
			{
				durum =true; 
				index += anahtar ; 
				if( index >=26) 
				index %= 26; 
				sifreliMetin[i]= alfabe [index]; 				
			}
			
		}
		if( ! durum ) 
		sifreliMetin[i] = metin[i]; 
		
		i++; 
		
	}
	
	sifreliMetin[i]= '\0'; 
	system("cls"); 
	cout<<"Sifreli Metin    : "<< sifreliMetin << endl; 	
} 


void KaySif::desifrele() 
{
 	
	int i=0; 
	while ( i < uzunluk ) 
	{
		bool durum =false; 
		for( int j=0; j<26; j++   ) 
		{
			int index=j; 
			if( sifreliMetin[i]== alfabe[j] ) 
			{
				durum =true; 
				index -= anahtar ; 
				if( index <0 ) 
				index += 26; 
				desifreliMetin[i]= alfabe [index]; 				
			}
			
		}
		if( ! durum ) 
		desifreliMetin[i] = sifreliMetin[i]; 
		
		i++; 
		
	}
	
	desifreliMetin[i]= '\0'; 
	system("cls"); 
	cout<<"deSifreli Metin  : "<< desifreliMetin << endl; 	
} 

void KaySif :: kaydet() 
{
	ofstream ofile ( "dosya.txt") ; 
	if(  ! ofile  ) 
	{
		cout<<"dosya olusturulamadi !";
		exit(1); 
	}
	
	 sifrele() ; 
	 
	 ofile.write((char *) sifreliMetin, sizeof(sifreliMetin)  ) ; 
	 ofile.close(); 
	 system("cls") ; 
	 
	 cout<<"Dosyaya kayit yapildi "<< endl; 	
}

void KaySif :: oku () 
{
	ifstream ifile ( "dosya.txt") ; 
	if(  ! ifile  ) 
	{
		cout<<"dosya bulunamadi  !";
		exit(1); 
	}
	 
	 
	 ifile.read((char *) sifreliMetin, sizeof(sifreliMetin)  ) ; 
	 ifile.close(); 
	 
	 desifrele() ; 
	 system("cls") ; 
	 
	 cout<<desifreliMetin<< endl; 
	 
	 cout<<"\nDosyadan okuma islemi tamamlandi  "<< endl; 
	
} 

int main(int argc, char** argv) {
	
	KaySif ks; 
	int secim= ks.menu() ;
	while( secim != 0 ) 
	{
		switch(secim ) 
		{
			case 1: ks.sifrele(); break; 
			case 2: ks.desifrele(); break; 
			case 3: ks.kaydet(); break; 
			case 4: ks.oku(); break; 			 
		}
		secim = ks.menu(); 
	}
	
	return 0;
}
